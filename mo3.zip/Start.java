import java.lang.*;
import frames.*;

public class Start
{
	public static void main(String args[])
	{
		Movie mv = new Movie();
		mv.setVisible(true);
	}
}
package interfaces;

import java.lang.*;
import entity.*;

public interface ICustomerRepo
{
	public void insertCustomer(Customer c);
	public void updateCustomer(Customer c);
}